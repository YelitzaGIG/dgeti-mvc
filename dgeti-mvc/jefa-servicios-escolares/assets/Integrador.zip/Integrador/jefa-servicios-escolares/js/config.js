// Configuración global de la aplicación

const CONFIG = {
    // URL del backend (cambiar cuando tengas el servidor)
    API_URL: 'http://localhost:5000/api',
    
    // Datos de la jefa (simulados, después vendrán del login)
    JEFA_DATA: {
        id: 1,
        nombre: 'María González',
        rol: 'jefa_servicios',
        departamento: 'Servicios Escolares'
    },
    
    // Configuración de tipos de permiso
    TIPOS_PERMISO: [
        { id: 'medica', nombre: 'Licencia médica', maxDias: 15 },
        { id: 'particular', nombre: 'Permiso particular', maxDias: 3 },
        { id: 'capacitacion', nombre: 'Capacitación', maxDias: 5 },
        { id: 'comision', nombre: 'Comisión oficial', maxDias: 10 }
    ]
};

// Función para mostrar notificaciones
function mostrarNotificacion(mensaje, tipo = 'info') {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = mensaje;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// Función para formatear fecha
function formatearFecha(fecha) {
    const f = new Date(fecha);
    return `${f.getDate().toString().padStart(2,'0')}/${(f.getMonth()+1).toString().padStart(2,'0')}/${f.getFullYear()}`;
}