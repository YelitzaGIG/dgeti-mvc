// generar-pdf.js - Lógica para generar, imprimir y descargar el permiso oficial

// Obtener datos de la solicitud aprobada (simulados)
// En producción, estos datos vendrían del backend después de aprobar
const datosPermiso = {
    folio: 'PER-2026-0124',
    fechaEmision: '16 de abril de 2026',
    solicitante: {
        nombre: 'Ana López García',
        rol: 'Docente',
        departamento: 'Matemáticas'
    },
    periodo: {
        inicio: '20 de abril de 2026',
        fin: '22 de abril de 2026',
        dias: 3
    },
    motivo: 'Licencia médica - Cirugía programada',
    comentarioOficial: 'Se autoriza con goce de sueldo. Presentar comprobante al reincorporarse.',
    jefa: {
        nombre: 'María González Hernández',
        cargo: 'Jefa de Servicios Escolares'
    }
};

document.addEventListener('DOMContentLoaded', () => {
    cargarDatosEnPermiso();
    inicializarEventos();
});

function cargarDatosEnPermiso() {
    document.getElementById('folioNumero').textContent = datosPermiso.folio;
    document.getElementById('fechaEmision').textContent = datosPermiso.fechaEmision;
    document.getElementById('permisoNombre').textContent = datosPermiso.solicitante.nombre;
    document.getElementById('permisoRol').textContent = datosPermiso.solicitante.rol;
    document.getElementById('permisoDepto').textContent = datosPermiso.solicitante.departamento;
    document.getElementById('periodoInicio').textContent = datosPermiso.periodo.inicio;
    document.getElementById('periodoFin').textContent = datosPermiso.periodo.fin;
    document.getElementById('totalDias').textContent = datosPermiso.periodo.dias;
    document.getElementById('permisoMotivo').textContent = datosPermiso.motivo;
    
    // Mostrar comentario si existe
    if (datosPermiso.comentarioOficial) {
        const comentarioBox = document.getElementById('comentarioOficialBox');
        comentarioBox.style.display = 'block';
        document.getElementById('comentarioOficialTexto').textContent = datosPermiso.comentarioOficial;
    }
}

function inicializarEventos() {
    // Botón cerrar / volver
    document.getElementById('closeModalBtn')?.addEventListener('click', volverAlDashboard);
    document.getElementById('volverBtn')?.addEventListener('click', volverAlDashboard);
    
    // Click fuera del modal
    document.getElementById('modalOverlay')?.addEventListener('click', (e) => {
        if (e.target === document.getElementById('modalOverlay')) {
            volverAlDashboard();
        }
    });
    
    // Imprimir
    document.getElementById('imprimirBtn')?.addEventListener('click', imprimirPermiso);
    
    // Descargar PDF
    document.getElementById('descargarBtn')?.addEventListener('click', descargarPDF);
    
    // Enviar por correo
    document.getElementById('enviarBtn')?.addEventListener('click', enviarPorCorreo);
}

function volverAlDashboard() {
    window.location.href = 'index.html';
}

function imprimirPermiso() {
    const elemento = document.getElementById('permisoDocumento');
    const ventanaImpresion = window.open('', '_blank');
    
    ventanaImpresion.document.write(`
        <html>
            <head>
                <title>Permiso Oficial ${datosPermiso.folio}</title>
                <link rel="stylesheet" href="css/permiso-preview.css">
                <style>
                    body { padding: 2rem; margin: 0; }
                    .modal-overlay, .modal-header, .modal-footer { display: none; }
                    .permiso-body { padding: 0; }
                </style>
            </head>
            <body>
                ${elemento.outerHTML}
            </body>
        </html>
    `);
    
    ventanaImpresion.document.close();
    ventanaImpresion.print();
    ventanaImpresion.close();
}

function descargarPDF() {
    const elemento = document.getElementById('permisoDocumento');
    
    // Configuración de html2pdf
    const opciones = {
        margin: [0.5, 0.5, 0.5, 0.5],
        filename: `Permiso_${datosPermiso.folio}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, letterRendering: true },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    
    // Mostrar notificación de proceso
    mostrarNotificacion('Generando PDF, espere un momento...', 'info');
    
    // Generar y descargar PDF
    html2pdf().set(opciones).from(elemento).save();
    
    setTimeout(() => {
        mostrarNotificacion('✅ PDF generado correctamente', 'success');
    }, 1000);
}

function enviarPorCorreo() {
    const email = 'ana.lopez@cbtis199.edu.mx'; // En producción, del solicitante
    
    // Simular envío de correo
    mostrarNotificacion(`✉️ Enviando permiso a ${email}...`, 'info');
    
    setTimeout(() => {
        mostrarNotificacion(`✅ Permiso enviado correctamente a ${email}`, 'success');
    }, 1500);
    
    // Aquí después se integrará con el backend para envío real
    console.log('Enviando correo a:', email, 'con folio:', datosPermiso.folio);
}