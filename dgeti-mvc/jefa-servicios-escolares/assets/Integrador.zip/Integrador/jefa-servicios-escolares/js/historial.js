// historial.js - Lógica para el historial de permisos firmados

// Datos simulados de permisos ya emitidos
let permisosData = [
    {
        id: 1,
        folio: 'PER-2026-0124',
        fechaEmision: '2026-04-16',
        fechaEmisionFormateada: '16/04/2026',
        solicitante: {
            nombre: 'Ana López García',
            rol: 'docente',
            departamento: 'Matemáticas'
        },
        periodo: {
            inicio: '2026-04-20',
            fin: '2026-04-22',
            inicioFormateado: '20/04/2026',
            finFormateado: '22/04/2026',
            dias: 3
        },
        documento: 'Permiso_PER-2026-0124.pdf'
    },
    {
        id: 2,
        folio: 'PER-2026-0123',
        fechaEmision: '2026-04-10',
        fechaEmisionFormateada: '10/04/2026',
        solicitante: {
            nombre: 'Carlos Ramírez Gómez',
            rol: 'administrativo',
            departamento: 'Recursos Humanos'
        },
        periodo: {
            inicio: '2026-04-11',
            fin: '2026-04-11',
            inicioFormateado: '11/04/2026',
            finFormateado: '11/04/2026',
            dias: 1
        },
        documento: 'Permiso_PER-2026-0123.pdf'
    },
    {
        id: 3,
        folio: 'PER-2026-0122',
        fechaEmision: '2026-04-05',
        fechaEmisionFormateada: '05/04/2026',
        solicitante: {
            nombre: 'Laura Mendoza Sánchez',
            rol: 'docente',
            departamento: 'Historia'
        },
        periodo: {
            inicio: '2026-04-07',
            fin: '2026-04-09',
            inicioFormateado: '07/04/2026',
            finFormateado: '09/04/2026',
            dias: 3
        },
        documento: 'Permiso_PER-2026-0122.pdf'
    },
    {
        id: 4,
        folio: 'PER-2026-0121',
        fechaEmision: '2026-03-28',
        fechaEmisionFormateada: '28/03/2026',
        solicitante: {
            nombre: 'Roberto Méndez Díaz',
            rol: 'docente',
            departamento: 'Física'
        },
        periodo: {
            inicio: '2026-03-30',
            fin: '2026-03-31',
            inicioFormateado: '30/03/2026',
            finFormateado: '31/03/2026',
            dias: 2
        },
        documento: 'Permiso_PER-2026-0121.pdf'
    },
    {
        id: 5,
        folio: 'PER-2026-0120',
        fechaEmision: '2026-03-20',
        fechaEmisionFormateada: '20/03/2026',
        solicitante: {
            nombre: 'Patricia Flores Ortiz',
            rol: 'administrativo',
            departamento: 'Control Escolar'
        },
        periodo: {
            inicio: '2026-03-22',
            fin: '2026-03-25',
            inicioFormateado: '22/03/2026',
            finFormateado: '25/03/2026',
            dias: 4
        },
        documento: 'Permiso_PER-2026-0120.pdf'
    },
    {
        id: 6,
        folio: 'PER-2026-0119',
        fechaEmision: '2026-03-15',
        fechaEmisionFormateada: '15/03/2026',
        solicitante: {
            nombre: 'Jorge Alberto Ruiz',
            rol: 'docente',
            departamento: 'Matemáticas'
        },
        periodo: {
            inicio: '2026-03-17',
            fin: '2026-03-18',
            inicioFormateado: '17/03/2026',
            finFormateado: '18/03/2026',
            dias: 2
        },
        documento: 'Permiso_PER-2026-0119.pdf'
    },
    {
        id: 7,
        folio: 'PER-2026-0118',
        fechaEmision: '2026-03-10',
        fechaEmisionFormateada: '10/03/2026',
        solicitante: {
            nombre: 'Silvia Elena Castro',
            rol: 'docente',
            departamento: 'Español'
        },
        periodo: {
            inicio: '2026-03-12',
            fin: '2026-03-14',
            inicioFormateado: '12/03/2026',
            finFormateado: '14/03/2026',
            dias: 3
        },
        documento: 'Permiso_PER-2026-0118.pdf'
    },
    {
        id: 9,
        folio: 'PER-2026-0116',
        fechaEmision: '2026-02-28',
        fechaEmisionFormateada: '28/02/2026',
        solicitante: {
            nombre: 'Martha Elena Ríos',
            rol: 'docente',
            departamento: 'Química'
        },
        periodo: {
            inicio: '2026-03-01',
            fin: '2026-03-05',
            inicioFormateado: '01/03/2026',
            finFormateado: '05/03/2026',
            dias: 5
        },
        documento: 'Permiso_PER-2026-0116.pdf'
    },
    {
        id: 8,
        folio: 'PER-2026-0117',
        fechaEmision: '2026-03-05',
        fechaEmisionFormateada: '05/03/2026',
        solicitante: {
            nombre: 'Fernando Torres Paz',
            rol: 'administrativo',
            departamento: 'Mantenimiento'
        },
        periodo: {
            inicio: '2026-03-07',
            fin: '2026-03-07',
            inicioFormateado: '07/03/2026',
            finFormateado: '07/03/2026',
            dias: 1
        },
        documento: 'Permiso_PER-2026-0117.pdf'
    }
];

// Variables de paginación
let paginaActual = 1;
const registrosPorPagina = 10;
let datosFiltrados = [...permisosData];

document.addEventListener('DOMContentLoaded', () => {
    inicializarEventos();
    actualizarResumen();
    renderizarTabla();
});

function inicializarEventos() {
    // Botones de navegación
    document.getElementById('volverBtn')?.addEventListener('click', () => {
        window.location.href = 'index.html';
    });
    
    document.getElementById('logoutBtn')?.addEventListener('click', () => {
        mostrarNotificacion('Sesión cerrada correctamente');
        // window.location.href = 'login.html';
    });
    
    // Botón de búsqueda/filtro
    document.getElementById('buscarBtn')?.addEventListener('click', () => {
        paginaActual = 1;
        aplicarFiltros();
    });
    
    // Enter en el campo de búsqueda
    document.getElementById('searchInput')?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            paginaActual = 1;
            aplicarFiltros();
        }
    });
    
    // Exportar a Excel
    document.getElementById('exportarBtn')?.addEventListener('click', exportarAExcel);
}

function aplicarFiltros() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const fechaDesde = document.getElementById('fechaDesde')?.value;
    const fechaHasta = document.getElementById('fechaHasta')?.value;
    const rolFiltro = document.getElementById('rolFiltro')?.value || 'todos';
    
    datosFiltrados = permisosData.filter(permiso => {
        // Filtro de búsqueda
        let cumpleBusqueda = true;
        if (searchTerm) {
            cumpleBusqueda = 
                permiso.folio.toLowerCase().includes(searchTerm) ||
                permiso.solicitante.nombre.toLowerCase().includes(searchTerm) ||
                permiso.solicitante.departamento.toLowerCase().includes(searchTerm);
        }
        
        // Filtro de rol
        let cumpleRol = true;
        if (rolFiltro !== 'todos') {
            cumpleRol = permiso.solicitante.rol === rolFiltro;
        }
        
        // Filtro de fechas
        let cumpleFechas = true;
        if (fechaDesde) {
            cumpleFechas = cumpleFechas && permiso.fechaEmision >= fechaDesde;
        }
        if (fechaHasta) {
            cumpleFechas = cumpleFechas && permiso.fechaEmision <= fechaHasta;
        }
        
        return cumpleBusqueda && cumpleRol && cumpleFechas;
    });
    
    renderizarTabla();
    actualizarResumen();
}

function actualizarResumen() {
    const total = datosFiltrados.length;
    const hoy = new Date();
    const inicioSemana = new Date(hoy);
    inicioSemana.setDate(hoy.getDate() - hoy.getDay());
    const inicioMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
    
    const esteMes = datosFiltrados.filter(p => new Date(p.fechaEmision) >= inicioMes).length;
    const estaSemana = datosFiltrados.filter(p => new Date(p.fechaEmision) >= inicioSemana).length;
    const docentes = datosFiltrados.filter(p => p.solicitante.rol === 'docente').length;
    const administrativos = datosFiltrados.filter(p => p.solicitante.rol === 'administrativo').length;
    
    document.getElementById('totalPermisos').textContent = total;
    document.getElementById('permisosMes').textContent = esteMes;
    document.getElementById('permisosSemana').textContent = estaSemana;
    document.getElementById('permisosDocentes').textContent = docentes;
    document.getElementById('permisosAdmin').textContent = administrativos;
}

function renderizarTabla() {
    const tbody = document.getElementById('historialBody');
    if (!tbody) return;
    
    const inicio = (paginaActual - 1) * registrosPorPagina;
    const fin = inicio + registrosPorPagina;
    const datosPagina = datosFiltrados.slice(inicio, fin);
    
    if (datosPagina.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" class="empty-state">📭 No se encontraron permisos registrados</td></tr>`;
        document.getElementById('paginacion').innerHTML = '';
        return;
    }
    
    tbody.innerHTML = datosPagina.map(permiso => `
        <tr>
            <td><a href="#" class="folio-link" data-id="${permiso.id}">${permiso.folio}</a></td>
            <td>${permiso.fechaEmisionFormateada}</td>
            <td>${permiso.solicitante.nombre}</td>
            <td>${permiso.solicitante.rol === 'docente' ? '👩‍🏫 Docente' : '📋 Administrativo'}</td>
            <td>${permiso.solicitante.departamento}</td>
            <td>${permiso.periodo.inicioFormateado} - ${permiso.periodo.finFormateado}</td>
            <td>${permiso.periodo.dias}</td>
            <td><a href="#" class="documento-link ver-documento" data-doc="${permiso.documento}">📄 Ver PDF</a></td>
            <td class="acciones-historial">
                <button class="btn-icon ver" data-id="${permiso.id}" title="Ver detalle">👁️</button>
                <button class="btn-icon descargar" data-id="${permiso.id}" title="Descargar PDF">📥</button>
                <button class="btn-icon email" data-id="${permiso.id}" title="Reenviar por correo">✉️</button>
            </td>
        </tr>
    `).join('');
    
    // Asignar eventos a los botones
    document.querySelectorAll('.btn-icon.ver').forEach(btn => {
        btn.addEventListener('click', (e) => verDetallePermiso(btn.dataset.id));
    });
    
    document.querySelectorAll('.btn-icon.descargar').forEach(btn => {
        btn.addEventListener('click', (e) => descargarPermiso(btn.dataset.id));
    });
    
    document.querySelectorAll('.btn-icon.email').forEach(btn => {
        btn.addEventListener('click', (e) => reenviarPorCorreo(btn.dataset.id));
    });
    
    document.querySelectorAll('.folio-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            verDetallePermiso(link.dataset.id);
        });
    });
    
    document.querySelectorAll('.ver-documento').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            mostrarNotificacion(`📄 Abriendo documento: ${link.dataset.doc}`, 'info');
        });
    });
    
    renderizarPaginacion();
}

function renderizarPaginacion() {
    const paginacionDiv = document.getElementById('paginacion');
    if (!paginacionDiv) return;
    
    const totalPaginas = Math.ceil(datosFiltrados.length / registrosPorPagina);
    
    if (totalPaginas <= 1) {
        paginacionDiv.innerHTML = '';
        return;
    }
    
    let botones = '';
    for (let i = 1; i <= totalPaginas; i++) {
        botones += `<button class="pag-btn ${i === paginaActual ? 'active' : ''}" data-pagina="${i}">${i}</button>`;
    }
    
    paginacionDiv.innerHTML = botones;
    
    document.querySelectorAll('.pag-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            paginaActual = parseInt(btn.dataset.pagina);
            renderizarTabla();
        });
    });
}

function verDetallePermiso(id) {
    const permiso = permisosData.find(p => p.id == id);
    if (permiso) {
        mostrarNotificacion(`👁️ Ver detalle de ${permiso.folio}`, 'info');
        // Aquí se podría abrir un modal con el detalle completo
        console.log('Detalle del permiso:', permiso);
    }
}

function descargarPermiso(id) {
    const permiso = permisosData.find(p => p.id == id);
    if (permiso) {
        mostrarNotificacion(`📥 Descargando ${permiso.folio}...`, 'success');
        // Simular descarga
        setTimeout(() => {
            mostrarNotificacion(`✅ ${permiso.folio} descargado`, 'success');
        }, 1000);
    }
}

function reenviarPorCorreo(id) {
    const permiso = permisosData.find(p => p.id == id);
    if (permiso) {
        const email = `${permiso.solicitante.nombre.toLowerCase().replace(/ /g, '.')}@cbtis199.edu.mx`;
        mostrarNotificacion(`✉️ Reenviando ${permiso.folio} a ${email}...`, 'info');
        setTimeout(() => {
            mostrarNotificacion(`✅ Permiso reenviado a ${email}`, 'success');
        }, 1500);
    }
}

function exportarAExcel() {
    mostrarNotificacion('📊 Generando reporte en Excel...', 'info');
    
    // Crear contenido CSV
    const headers = ['Folio', 'Fecha Emisión', 'Solicitante', 'Rol', 'Departamento', 'Fecha Inicio', 'Fecha Fin', 'Días'];
    const rows = datosFiltrados.map(p => [
        p.folio,
        p.fechaEmisionFormateada,
        p.solicitante.nombre,
        p.solicitante.rol === 'docente' ? 'Docente' : 'Administrativo',
        p.solicitante.departamento,
        p.periodo.inicioFormateado,
        p.periodo.finFormateado,
        p.periodo.dias
    ]);
    
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.setAttribute('download', `historial_permisos_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    setTimeout(() => {
        mostrarNotificacion('✅ Reporte exportado correctamente', 'success');
    }, 500);
}