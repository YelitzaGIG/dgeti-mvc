// Dashboard principal - Lógica de la página

document.addEventListener('DOMContentLoaded', () => {
    inicializarEventos();
    cargarEstadisticas();
    cargarSolicitudes();
});

// Inicializar eventos de los elementos interactivos
function inicializarEventos() {
    // Botón buscar
    document.getElementById('buscarBtn')?.addEventListener('click', () => {
        cargarSolicitudes();
    });
    
    // Vistas rápidas
    document.querySelectorAll('.vista-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const vista = e.target.dataset.vista;
            aplicarVistaRapida(vista);
        });
    });
    
    // Pestañas
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Cambiar pestaña activa visualmente
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            
            // Recargar solicitudes según la pestaña
            const tab = e.target.dataset.tab;
            cargarSolicitudes(tab);
        });
    });
    
    // Botón de logout
    document.getElementById('logoutBtn')?.addEventListener('click', () => {
        mostrarNotificacion('Sesión cerrada correctamente');
        // Redirigir al login (cuando exista)
        // window.location.href = 'login.html';
    });

    // Botón de configuración
    document.getElementById('irConfigBtn')?.addEventListener('click', () => {
    window.location.href = 'configuracion.html';
    });
}

// Aplicar filtro de vista rápida (hoy, semana, mes)
function aplicarVistaRapida(vista) {
    const hoy = new Date();
    let fechaDesde = null;
    let fechaHasta = new Date();
    
    switch(vista) {
        case 'hoy':
            fechaDesde = hoy;
            break;
        case 'semana':
            fechaDesde = new Date();
            fechaDesde.setDate(hoy.getDate() - 7);
            break;
        case 'mes':
            fechaDesde = new Date();
            fechaDesde.setMonth(hoy.getMonth() - 1);
            break;
    }
    
    if(fechaDesde) {
        document.getElementById('fechaDesde').value = fechaDesde.toISOString().split('T')[0];
        document.getElementById('fechaHasta').value = fechaHasta.toISOString().split('T')[0];
        cargarSolicitudes();
    }
}

// Cargar estadísticas (simuladas por ahora)
async function cargarEstadisticas() {
    // Aquí después se conectará al backend
    // Por ahora usamos datos de ejemplo
    const stats = {
        pendientes: 12,
        aprobados: 45,
        rechazados: 8,
        generados: 32
    };
    
    document.getElementById('pendientesCount').textContent = stats.pendientes;
    document.getElementById('aprobadosCount').textContent = stats.aprobados;
    document.getElementById('rechazadosCount').textContent = stats.rechazados;
    document.getElementById('generadosCount').textContent = stats.generados;
}

// Cargar solicitudes según filtros
async function cargarSolicitudes(estado = null) {
    // Obtener valores de filtros
    const searchText = document.getElementById('searchText')?.value.toLowerCase() || '';
    const tipo = document.getElementById('tipoFiltro')?.value || 'todos';
    const estadoFiltro = estado || document.getElementById('estadoFiltro')?.value || 'todos';
    const departamento = document.getElementById('departamentoFiltro')?.value || 'todos';
    const fechaDesde = document.getElementById('fechaDesde')?.value || '';
    const fechaHasta = document.getElementById('fechaHasta')?.value || '';
    
    console.log('Filtros aplicados:', { searchText, tipo, estadoFiltro, departamento, fechaDesde, fechaHasta });
    
    // Aquí se filtrarán los datos de la tabla
    filtrarTabla(searchText, tipo, estadoFiltro, departamento, fechaDesde, fechaHasta);
}

function filtrarTabla(searchText, tipo, estado, depto, fechaDesde, fechaHasta) {
    const filas = document.querySelectorAll('#solicitudesTable tbody tr');
    
    filas.forEach(fila => {
        let mostrar = true;
        
        // Obtener texto de las celdas
        const solicitanteText = fila.cells[2]?.textContent.toLowerCase() || '';
        const tipoText = fila.cells[3]?.textContent.toLowerCase() || '';
        const fechaSolicitud = fila.cells[1]?.textContent || '';
        
        // Filtrar por texto de búsqueda
        if (searchText && !solicitanteText.includes(searchText)) {
            mostrar = false;
        }
        
        // Filtrar por tipo
        if (tipo !== 'todos' && !tipoText.includes(tipo)) {
            mostrar = false;
        }
        
        // Mostrar u ocultar fila
        fila.style.display = mostrar ? '' : 'none';
    });
}

// Función global para ver detalle de solicitud
window.verDetalle = function(id) {
    // Redirigir a la página de revisión con el ID
    window.location.href = `revisar-solicitud.html?id=${id}`;
};

// Función global para aprobar
window.aprobarSolicitud = function(id) {
    mostrarNotificacion(`Solicitud #${id} aprobada`);
    // Aquí llamar al backend
};

// Función global para rechazar
window.rechazarSolicitud = function(id) {
    mostrarNotificacion(`Solicitud #${id} rechazada`);
    // Aquí llamar al backend
};

// Asignar eventos dinámicamente a los botones de la tabla
function asignarEventosTabla() {
    document.querySelectorAll('.btn-ver').forEach(btn => {
        btn.removeEventListener('click', () => {});
        btn.addEventListener('click', (e) => {
            const id = btn.dataset.id;
            window.verDetalle(id);
        });
    });
    
    document.querySelectorAll('.btn-aprobar').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = btn.dataset.id;
            window.aprobarSolicitud(id);
        });
    });
    
    document.querySelectorAll('.btn-rechazar').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = btn.dataset.id;
            window.rechazarSolicitud(id);
        });
    });
}

// Llamar a asignar eventos después de cargar la tabla
setTimeout(asignarEventosTabla, 100);