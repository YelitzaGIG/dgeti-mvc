// revisar.js - Lógica para el modal de revisión de solicitudes

// Obtener ID de la solicitud desde la URL (ej: ?id=124)
const urlParams = new URLSearchParams(window.location.search);
const solicitudId = urlParams.get('id') || '124';

// Simular datos de la solicitud (después vendrán del backend)
const datosSolicitud = {
    124: {
        id: 124,
        solicitante: {
            nombre: 'Ana López García',
            rol: 'Docente',
            departamento: 'Matemáticas',
            antiguedad: '8 años',
            email: 'ana.lopez@cbtis199.edu.mx'
        },
        solicitud: {
            tipo: 'Licencia médica',
            fechaSolicitud: '15 de abril de 2026',
            periodoAusencia: '20 al 22 de abril de 2026',
            diasSolicitados: 3,
            motivo: 'Cirugía programada - recuperación postoperatoria. Adjunto certificado médico.',
            documento: 'certificado_medico.pdf',
            observaciones: 'Solicito con anticipación para organizar las clases.',
            maxDias: 15
        }
    },
    // Datos de ejemplo para más solicitudes
    2: {
        id: 2,
        solicitante: {
            nombre: 'Carlos Ramírez',
            rol: 'Administrativo',
            departamento: 'Recursos Humanos',
            antiguedad: '3 años',
            email: 'carlos.ramirez@cbtis199.edu.mx'
        },
        solicitud: {
            tipo: 'Permiso particular',
            fechaSolicitud: '14 de abril de 2026',
            periodoAusencia: '18 de abril de 2026',
            diasSolicitados: 1,
            motivo: 'Trámites personales',
            documento: 'carta_permiso.pdf',
            observaciones: 'Solicito medio día',
            maxDias: 3
        }
    }
};

// Cargar datos al modal
document.addEventListener('DOMContentLoaded', () => {
    cargarDatosEnModal(solicitudId);
    inicializarEventos();
});

function cargarDatosEnModal(id) {
    const data = datosSolicitud[id] || datosSolicitud[124]; // Fallback al 124
    
    if (!data) return;
    
    // Asignar valores a los elementos del DOM
    document.getElementById('solicitudId').textContent = data.id;
    document.getElementById('solicitanteNombre').textContent = data.solicitante.nombre;
    document.getElementById('solicitanteRol').textContent = data.solicitante.rol;
    document.getElementById('solicitanteDepto').textContent = data.solicitante.departamento;
    document.getElementById('solicitanteAntiguedad').textContent = data.solicitante.antiguedad;
    document.getElementById('solicitanteEmail').textContent = data.solicitante.email;
    
    document.getElementById('solicitudTipo').textContent = data.solicitud.tipo;
    document.getElementById('solicitudFecha').textContent = data.solicitud.fechaSolicitud;
    document.getElementById('solicitudPeriodo').textContent = data.solicitud.periodoAusencia;
    document.getElementById('solicitudDias').textContent = `${data.solicitud.diasSolicitados} días`;
    document.getElementById('solicitudMotivo').textContent = data.solicitud.motivo;
    document.getElementById('solicitudObservaciones').textContent = data.solicitud.observaciones;
    
    // Configurar enlace del documento
    const docLink = document.getElementById('documentoLink');
    docLink.href = `assets/documentos/${data.solicitud.documento}`;
    docLink.textContent = `📄 ${data.solicitud.documento}`;
    
    // Configurar máximo de días autorizados
    const inputDias = document.getElementById('diasAutorizados');
    inputDias.max = data.solicitud.maxDias;
    inputDias.value = data.solicitud.diasSolicitados;
    
    // Mostrar el máximo en el texto
    const maxSpan = document.querySelector('.dias-max');
    if (maxSpan) maxSpan.textContent = `(máx: ${data.solicitud.maxDias} días)`;
}

function inicializarEventos() {
    // Botón cerrar
    document.getElementById('closeModalBtn')?.addEventListener('click', cerrarModal);
    document.getElementById('cancelarBtn')?.addEventListener('click', cerrarModal);
    
    // Click fuera del modal (en el overlay)
    document.getElementById('modalOverlay')?.addEventListener('click', (e) => {
        if (e.target === document.getElementById('modalOverlay')) {
            cerrarModal();
        }
    });
    
    // Botón Aprobar
    document.getElementById('aprobarBtn')?.addEventListener('click', () => {
        const diasAutorizados = document.getElementById('diasAutorizados').value;
        const comentario = document.getElementById('comentarioOficial').value;
        aprobarSolicitud(diasAutorizados, comentario);
    });
    
    // Botón Rechazar
    document.getElementById('rechazarBtn')?.addEventListener('click', () => {
        const comentario = document.getElementById('comentarioOficial').value;
        rechazarSolicitud(comentario);
    });
}

function cerrarModal() {
    // Redirigir de vuelta al dashboard
    window.location.href = 'index.html';
}

function aprobarSolicitud(dias, comentario) {
    const id = document.getElementById('solicitudId').textContent;
    
    // Guardar datos de la aprobación (simulado)
    const datosAprobacion = {
        id: id,
        diasAutorizados: dias,
        comentario: comentario,
        fechaAprobacion: new Date().toLocaleDateString('es-ES')
    };
    
    // Guardar en sessionStorage para pasar al generador
    sessionStorage.setItem('solicitudAprobada', JSON.stringify(datosAprobacion));
    
    // Mostrar mensaje y redirigir al generador de permiso
    mostrarNotificacion(`✅ Solicitud #${id} aprobada. Generando permiso oficial...`, 'success');
    
    setTimeout(() => {
        window.location.href = 'generar-permiso.html';
    }, 1000);
}

function rechazarSolicitud(comentario) {
    const id = document.getElementById('solicitudId').textContent;
    
    // Mostrar mensaje
    mostrarNotificacion(`❌ Solicitud #${id} rechazada`, 'error');
    
    // Aquí después se enviará al backend
    console.log('Rechazada:', { id, comentario });
    
    // Redirigir después de 1.5 segundos
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1500);
}